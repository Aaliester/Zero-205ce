const $ = (s) => document.querySelector(s);
const chat = $("#chat"), form = $("#form"), input = $("#input"), sendBtn = $("#send"), statusEl = $("#status"),
      tray = $("#tray"), menu = $("#menu"), micBtn = $("#mic"), fileIn = $("#fileIn"), camIn = $("#camIn"),
      drop = $("#drop"), toastEl = $("#toast");
const KEY = "zero-ai:history:v2";
const ICON = {
  send: '<svg viewBox="0 0 24 24"><path d="M12 19V5M5 12l7-7 7 7"/></svg>',
  stop: '<svg viewBox="0 0 24 24"><rect x="6" y="6" width="12" height="12" rx="2" fill="currentColor"/></svg>',
};
let history = [], pending = [], busy = false, ctrl = null;
const raw = new WeakMap();
try { history = JSON.parse(localStorage.getItem(KEY) || "[]"); } catch {}
const save = () => { try { localStorage.setItem(KEY, JSON.stringify(history.slice(-30).map(({ images, ...m }) => m))); } catch {} };

/* ---------- helpers ---------- */
const esc = (s) => s.replace(/[&<>"]/g, (c) => ({ "&": "&amp;", "<": "&lt;", ">": "&gt;", '"': "&quot;" }[c]));
let toastT;
function toast(msg) { toastEl.textContent = msg; toastEl.classList.add("on"); clearTimeout(toastT); toastT = setTimeout(() => toastEl.classList.remove("on"), 3600); }
const near = () => chat.scrollHeight - chat.scrollTop - chat.clientHeight < 150;
const toEnd = () => { chat.scrollTop = chat.scrollHeight; };
const fit = () => { input.style.height = "auto"; input.style.height = Math.min(input.scrollHeight, 180) + "px"; };
const upd = () => { sendBtn.disabled = !busy && !input.value.trim() && !pending.length; };
const setBusy = (b) => { busy = b; sendBtn.innerHTML = b ? ICON.stop : ICON.send; upd(); };
const kb = (n) => n < 1024 ? n + " B" : n < 1048576 ? (n / 1024).toFixed(0) + " KB" : (n / 1048576).toFixed(1) + " MB";

/* ---------- tiny safe markdown ---------- */
function inline(s) {
  return esc(s)
    .replace(/`([^`\n]+)`/g, "<code>$1</code>")
    .replace(/\*\*([^*\n]+)\*\*/g, "<strong>$1</strong>")
    .replace(/(^|[^*])\*([^*\n]+)\*/g, "$1<em>$2</em>")
    .replace(/\[([^\]]+)\]\((https?:\/\/[^\s)]+)\)/g, '<a href="$2" target="_blank" rel="noopener noreferrer">$1</a>');
}
function md(text) {
  const blocks = [];
  text = text.replace(/```(\w*)\n?([\s\S]*?)(```|$)/g, (_, lang, code) => { blocks.push({ lang, code: code.replace(/\n$/, "") }); return `\u0000${blocks.length - 1}\u0000`; });
  let out = "", list = null, para = [];
  const fp = () => { if (para.length) { out += `<p>${inline(para.join("\n")).replace(/\n/g, "<br>")}</p>`; para = []; } };
  const fl = () => { if (list) { out += `</${list}>`; list = null; } };
  for (const r of text.split("\n")) {
    const line = r.trimEnd(); let m;
    if ((m = line.match(/^\u0000(\d+)\u0000$/))) { fp(); fl(); const b = blocks[+m[1]]; out += `<div class="code"><div class="code-head"><span>${esc(b.lang || "code")}</span><button class="copy" type="button">copy</button></div><pre><code>${esc(b.code)}</code></pre></div>`; }
    else if ((m = line.match(/^(#{1,4})\s+(.*)/))) { fp(); fl(); const n = Math.min(m[1].length + 1, 4); out += `<h${n}>${inline(m[2])}</h${n}>`; }
    else if ((m = line.match(/^\s*[-*•]\s+(.*)/))) { fp(); if (list !== "ul") { fl(); out += "<ul>"; list = "ul"; } out += `<li>${inline(m[1])}</li>`; }
    else if ((m = line.match(/^\s*\d+[.)]\s+(.*)/))) { fp(); if (list !== "ol") { fl(); out += "<ol>"; list = "ol"; } out += `<li>${inline(m[1])}</li>`; }
    else if ((m = line.match(/^>\s?(.*)/))) { fp(); fl(); out += `<blockquote>${inline(m[1])}</blockquote>`; }
    else if (!line.trim()) { fp(); fl(); }
    else { fl(); para.push(line); }
  }
  fp(); fl();
  return out;
}

/* ---------- file reading ---------- */
const TEXT_EXT = /\.(txt|md|markdown|csv|tsv|json|jsonl|xml|html?|css|scss|js|mjs|cjs|jsx|ts|tsx|py|java|c|h|cpp|hpp|cs|go|rs|rb|php|swift|kt|sql|sh|bash|ya?ml|toml|ini|cfg|conf|log|lua|dart|vue|svelte|tex|srt|r)$/i;
const MAX_TEXT = 40000, MAX_TOTAL = 120000, MAX_BYTES = 15 * 1048576;
const PDFJS = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.min.js";
const PDFJS_WORKER = "https://cdnjs.cloudflare.com/ajax/libs/pdf.js/3.11.174/pdf.worker.min.js";
const MAMMOTH = "https://cdnjs.cloudflare.com/ajax/libs/mammoth/1.6.0/mammoth.browser.min.js";
const loadScript = (src) => new Promise((res, rej) => {
  const s = document.createElement("script"); s.src = src; s.onload = res; s.onerror = () => rej(new Error("reader failed to load")); document.head.appendChild(s);
});
async function readPdf(file) {
  if (!window.pdfjsLib) await loadScript(PDFJS);
  window.pdfjsLib.GlobalWorkerOptions.workerSrc = PDFJS_WORKER;
  const pdf = await window.pdfjsLib.getDocument({ data: await file.arrayBuffer() }).promise;
  let out = "";
  for (let i = 1; i <= Math.min(pdf.numPages, 40) && out.length < MAX_TEXT; i++) {
    const tc = await (await pdf.getPage(i)).getTextContent();
    out += `\n--- page ${i} ---\n` + tc.items.map((t) => t.str).join(" ");
  }
  return out.trim();
}
async function readDocx(file) {
  if (!window.mammoth) await loadScript(MAMMOTH);
  return (await window.mammoth.extractRawText({ arrayBuffer: await file.arrayBuffer() })).value.trim();
}
async function readImage(file) {
  const bmp = await createImageBitmap(file);
  const s = Math.min(1, 1280 / Math.max(bmp.width, bmp.height));
  const c = document.createElement("canvas"); c.width = Math.round(bmp.width * s); c.height = Math.round(bmp.height * s);
  const x = c.getContext("2d"); x.fillStyle = "#fff"; x.fillRect(0, 0, c.width, c.height); x.drawImage(bmp, 0, 0, c.width, c.height);
  return c.toDataURL("image/jpeg", 0.82);
}
async function addFiles(list) {
  for (const f of [...list]) {
    if (f.size > MAX_BYTES) { toast(`${f.name} is over 15 MB`); continue; }
    try {
      const n = f.name.toLowerCase();
      if (f.type.startsWith("image/")) {
        if (pending.filter((p) => p.kind === "image").length >= 3) { toast("Up to 3 images per message"); continue; }
        pending.push({ kind: "image", name: f.name || "photo.jpg", size: f.size, dataUrl: await readImage(f) });
      } else {
        let text;
        if (n.endsWith(".pdf")) { toast("Reading PDF…"); text = await readPdf(f); }
        else if (n.endsWith(".docx")) { toast("Reading document…"); text = await readDocx(f); }
        else if (f.type.startsWith("text/") || TEXT_EXT.test(n)) text = await f.text();
        else { toast(`${f.name}: unsupported type`); continue; }
        if (!text.trim()) { toast(`${f.name}: no readable text found (scanned PDF?)`); continue; }
        const used = pending.reduce((a, p) => a + (p.text?.length || 0), 0);
        const room = Math.min(MAX_TEXT, MAX_TOTAL - used);
        if (room <= 0) { toast("Too much file text in one message"); continue; }
        pending.push({ kind: "text", name: f.name, size: f.size, text: text.slice(0, room), truncated: text.length > room });
      }
    } catch (e) { toast(`Couldn't read ${f.name}`); }
  }
  renderTray(); upd();
}
function renderTray() {
  tray.innerHTML = "";
  pending.forEach((a, i) => {
    const el = document.createElement("div"); el.className = "att";
    if (a.kind === "image") { const im = document.createElement("img"); im.src = a.dataUrl; el.append(im); }
    else { const ic = document.createElement("div"); ic.className = "ic"; ic.textContent = (a.name.split(".").pop() || "file").slice(0, 4).toUpperCase(); el.append(ic); }
    const t = document.createElement("span"); t.textContent = a.name; const sm = document.createElement("small"); sm.textContent = kb(a.size);
    const x = document.createElement("button"); x.type = "button"; x.textContent = "×"; x.setAttribute("aria-label", "Remove");
    x.onclick = () => { pending.splice(i, 1); renderTray(); upd(); };
    el.append(t, sm, x); tray.append(el);
  });
}

/* ---------- rendering turns ---------- */
const clock = () => new Date().toLocaleTimeString([], { hour: "2-digit", minute: "2-digit" });
function addTurn(role) {
  $("#welcome")?.remove();
  chat.querySelectorAll(".regen").forEach((b) => b.remove());
  const t = document.createElement("div"); t.className = `turn ${role}`;
  t.innerHTML = `<div class="who"><b>${role === "user" ? "You" : "Zero"}</b><small>${clock()}</small></div><div class="body"></div>`;
  chat.appendChild(t); toEnd();
  return { turn: t, body: t.querySelector(".body") };
}
function addUser(text, files = [], images = []) {
  const { turn, body } = addTurn("user");
  body.textContent = text;
  if (files.length || images.length) {
    const c = document.createElement("div"); c.className = "chips";
    images.forEach((u) => { const im = document.createElement("img"); im.src = u; im.alt = "attachment"; c.append(im); });
    files.filter((f) => !f.image).forEach((f) => { const s = document.createElement("span"); s.textContent = "📎 " + f.name; c.append(s); });
    body.append(c);
  }
  return turn;
}
function addActions(turn, text, withRegen) {
  const a = document.createElement("div"); a.className = "acts";
  a.innerHTML = '<button data-a="copy" type="button">copy</button><button data-a="speak" type="button">listen</button>' + (withRegen ? '<button class="regen" data-a="regen" type="button">retry</button>' : "");
  turn.querySelector(".body").after(a); raw.set(turn, text);
}
function addBot(text, withRegen) { const { turn, body } = addTurn("bot"); body.innerHTML = md(text); addActions(turn, text, withRegen); }

/* ---------- chat ---------- */
async function send(text) {
  text = (text ?? "").trim();
  if (busy || (!text && !pending.length)) return;
  if (!text) text = "Please analyse the attached file(s) and tell me what matters.";
  let content = text; const files = [], images = [];
  pending.forEach((a) => {
    if (a.kind === "image") { images.push(a.dataUrl); files.push({ name: a.name, image: true }); }
    else { content += `\n\n[Attached file: ${a.name}${a.truncated ? " (truncated)" : ""}]\n\`\`\`\n${a.text}\n\`\`\``; files.push({ name: a.name }); }
  });
  if (images.length) content += `\n\n[${images.length} image(s) attached]`;
  history.push({ role: "user", content, display: text, files, images });
  const userEl = addUser(text, files, images);
  pending = []; renderTray(); input.value = ""; fit();
  await run(userEl, text);
}

async function run(userEl, restoreText) {
  const { turn, body } = addTurn("bot");
  turn.classList.add("live");
  body.innerHTML = '<span class="think">thinking<i>.</i><i>.</i><i>.</i></span>';
  setBusy(true); ctrl = new AbortController();
  let acc = "", raf = 0;
  const paint = (final) => { raf = 0; const n = near(); body.innerHTML = md(acc) + (final ? "" : '<span class="cur"></span>'); if (n) toEnd(); };
  const fail = (msg) => {
    if (msg) { body.innerHTML = `<span class="err">${esc(msg)}</span>`; turn.classList.remove("live"); } else turn.remove();
    if (history.at(-1)?.role === "user") history.pop();
    userEl?.remove(); if (restoreText) { input.value = restoreText; fit(); }
  };
  try {
    const messages = history.map((m, i) => (m.role === "user" && i === history.length - 1 && m.images?.length)
      ? { role: "user", content: [{ type: "text", text: m.content }, ...m.images.map((u) => ({ type: "image_url", image_url: { url: u } }))] }
      : { role: m.role, content: m.content });
    const res = await fetch("/api/chat", { method: "POST", headers: { "Content-Type": "application/json" }, body: JSON.stringify({ messages }), signal: ctrl.signal });
    if (!res.ok) {
      const e = await res.json().catch(() => ({}));
      throw new Error(e.error || (res.status === 404 ? "Zero's server function wasn't found (404). Deploy via Git or the Netlify CLI so functions are included." : `Server error (HTTP ${res.status}). Check Netlify → Logs → Functions.`));
    }
    const reader = res.body.getReader(), dec = new TextDecoder();
    for (;;) {
      const { done, value } = await reader.read(); if (done) break;
      acc += dec.decode(value, { stream: true });
      if (!raf) raf = requestAnimationFrame(paint);
    }
    cancelAnimationFrame(raf);
    if (!acc.trim()) throw new Error("I came back empty-handed. Try again.");
    paint(true); turn.classList.remove("live");
    history.push({ role: "assistant", content: acc, display: acc });
    addActions(turn, acc, true); save();
  } catch (e) {
    cancelAnimationFrame(raf);
    if (e.name === "AbortError") { if (acc.trim()) { paint(true); turn.classList.remove("live"); history.push({ role: "assistant", content: acc, display: acc }); addActions(turn, acc, true); save(); } else fail(null); }
    else fail(e.message);
  } finally { setBusy(false); ctrl = null; input.focus({ preventScroll: true }); }
}

/* ---------- speech ---------- */
function speak(text, btn) {
  if (!("speechSynthesis" in window)) return toast("Read-aloud isn't supported in this browser");
  if (speechSynthesis.speaking) { speechSynthesis.cancel(); document.querySelectorAll('[data-a=speak]').forEach((b) => (b.textContent = "listen")); return; }
  const u = new SpeechSynthesisUtterance(text.replace(/```[\s\S]*?```/g, " code block. ").replace(/[*_`#>]/g, ""));
  u.onend = u.onerror = () => (btn.textContent = "listen"); btn.textContent = "stop"; speechSynthesis.speak(u);
}
const SR = window.SpeechRecognition || window.webkitSpeechRecognition;
let rec = null, listening = false;
if (!SR) micBtn.hidden = true;
micBtn.onclick = () => {
  if (listening) return rec.stop();
  rec = new SR(); rec.lang = navigator.language || "en-US"; rec.interimResults = true; rec.continuous = true;
  const base = input.value;
  rec.onresult = (e) => { let t = ""; for (let i = 0; i < e.results.length; i++) t += e.results[i][0].transcript; input.value = (base ? base + " " : "") + t; fit(); upd(); };
  rec.onstart = () => { listening = true; micBtn.classList.add("on"); };
  rec.onend = () => { listening = false; micBtn.classList.remove("on"); };
  rec.onerror = (e) => { if (e.error === "not-allowed" || e.error === "service-not-allowed") toast("Microphone blocked — allow it in your browser's site settings, then tap again."); };
  try { rec.start(); } catch {}
};

/* ---------- events ---------- */
form.addEventListener("submit", (e) => { e.preventDefault(); busy ? ctrl?.abort() : send(input.value); });
input.addEventListener("keydown", (e) => { if (e.key === "Enter" && !e.shiftKey && !e.isComposing) { e.preventDefault(); if (!busy) send(input.value); } });
input.addEventListener("input", () => { fit(); upd(); });
input.addEventListener("paste", (e) => { const f = e.clipboardData?.files; if (f?.length) { e.preventDefault(); addFiles(f); } });
$("#plus").onclick = (e) => { e.stopPropagation(); menu.hidden = !menu.hidden; };
document.addEventListener("click", (e) => { if (!e.target.closest(".attach")) menu.hidden = true; });
const act = (a) => { menu.hidden = true; (a === "photo" ? camIn : fileIn).click(); };
document.addEventListener("click", (e) => {
  const b = e.target.closest("[data-act]"); if (b) act(b.dataset.act);
  const s = e.target.closest("[data-say]"); if (s) send(s.dataset.say);
});
[fileIn, camIn].forEach((i) => i.addEventListener("change", () => { addFiles(i.files); i.value = ""; }));
chat.addEventListener("click", (e) => {
  const c = e.target.closest(".copy");
  if (c) { navigator.clipboard?.writeText(c.closest(".code").querySelector("code").textContent); c.textContent = "copied ✓"; setTimeout(() => (c.textContent = "copy"), 1500); return; }
  const b = e.target.closest("[data-a]"); if (!b) return;
  const turn = b.closest(".turn"), text = raw.get(turn) || "";
  if (b.dataset.a === "copy") { navigator.clipboard?.writeText(text); b.textContent = "copied ✓"; setTimeout(() => (b.textContent = "copy"), 1500); }
  else if (b.dataset.a === "speak") speak(text, b);
  else if (b.dataset.a === "regen" && !busy) { if (history.at(-1)?.role === "assistant") history.pop(); turn.remove(); run(null, null); }
});
let dragN = 0;
const hasFiles = (e) => [...(e.dataTransfer?.types || [])].includes("Files");
addEventListener("dragenter", (e) => { if (hasFiles(e)) { dragN++; drop.classList.add("on"); } });
addEventListener("dragleave", (e) => { if (hasFiles(e) && --dragN <= 0) { dragN = 0; drop.classList.remove("on"); } });
addEventListener("dragover", (e) => { if (hasFiles(e)) e.preventDefault(); });
addEventListener("drop", (e) => { if (!hasFiles(e)) return; e.preventDefault(); dragN = 0; drop.classList.remove("on"); addFiles(e.dataTransfer.files); });
$("#theme").onclick = () => { const t = document.documentElement.dataset.theme === "dark" ? "light" : "dark"; document.documentElement.dataset.theme = t; try { localStorage.setItem("zero-theme", t); } catch {} };
$("#newChat").onclick = () => { ctrl?.abort(); window.speechSynthesis?.cancel(); history = []; save(); location.reload(); };

/* ---------- boot ---------- */
(function boot() {
  const h = new Date().getHours();
  const k = $("#kicker"); if (k) k.textContent = h < 5 ? "burning the midnight oil?" : h < 12 ? "good morning" : h < 18 ? "good afternoon" : "good evening";
  if (history.length) {
    $("#welcome")?.remove();
    const last = history.length - 1;
    history.forEach((m, i) => m.role === "user" ? addUser(m.display ?? m.content, m.files || []) : addBot(m.content, i === last));
    toEnd();
  }
  sendBtn.innerHTML = ICON.send; upd();
  fetch("/api/health").then((r) => r.json()).then((d) => {
    statusEl.className = "status " + (d.configured ? "on" : "off");
    statusEl.lastElementChild.textContent = d.configured ? "online" : "setup needed";
  }).catch(() => { statusEl.className = "status off"; statusEl.lastElementChild.textContent = "offline"; });
})();
